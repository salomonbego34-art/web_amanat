import { db } from "./db";
import {
  articles,
  upvotes,
  type Article,
  type InsertArticle,
  type Upvote,
  type ArticleResponse,
} from "@shared/schema";
import { eq, desc, sql, and } from "drizzle-orm";
import { users } from "@shared/models/auth";

export interface IStorage {
  getArticles(currentUserId?: string): Promise<ArticleResponse[]>;
  createArticle(article: InsertArticle & { authorId: string }): Promise<Article>;
  getArticle(id: number): Promise<Article | undefined>;
  toggleUpvote(articleId: number, userId: string): Promise<{ upvoted: boolean, upvoteCount: number }>;
}

export class DatabaseStorage implements IStorage {
  async getArticles(currentUserId?: string): Promise<ArticleResponse[]> {
    const allArticles = await db.query.articles.findMany({
      with: {
        author: true,
        upvotes: true,
      },
      orderBy: [desc(articles.createdAt)],
    });

    return allArticles.map(a => {
      const upvoteCount = a.upvotes.length;
      const hasUpvoted = currentUserId ? a.upvotes.some(u => u.userId === currentUserId) : false;
      return {
        ...a,
        upvoteCount,
        hasUpvoted,
      };
    });
  }

  async createArticle(article: InsertArticle & { authorId: string }): Promise<Article> {
    const [newArticle] = await db.insert(articles).values(article).returning();
    return newArticle;
  }

  async getArticle(id: number): Promise<Article | undefined> {
    const [article] = await db.select().from(articles).where(eq(articles.id, id));
    return article;
  }

  async toggleUpvote(articleId: number, userId: string): Promise<{ upvoted: boolean, upvoteCount: number }> {
    const existing = await db.select().from(upvotes).where(and(eq(upvotes.articleId, articleId), eq(upvotes.userId, userId)));
    let upvoted = false;
    if (existing.length > 0) {
      await db.delete(upvotes).where(and(eq(upvotes.articleId, articleId), eq(upvotes.userId, userId)));
      upvoted = false;
    } else {
      await db.insert(upvotes).values({ articleId, userId });
      upvoted = true;
    }
    const currentUpvotes = await db.select().from(upvotes).where(eq(upvotes.articleId, articleId));
    return { upvoted, upvoteCount: currentUpvotes.length };
  }
}

export const storage = new DatabaseStorage();