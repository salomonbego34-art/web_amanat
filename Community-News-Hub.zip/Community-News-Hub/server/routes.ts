import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { setupAuth, registerAuthRoutes, isAuthenticated, authStorage } from "./replit_integrations/auth";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // 1. Setup Auth
  await setupAuth(app);
  registerAuthRoutes(app);

  // 2. Application Routes
  app.get(api.articles.list.path, async (req: any, res) => {
    const userId = req.user?.claims?.sub;
    const articles = await storage.getArticles(userId);
    res.status(200).json(articles);
  });

  app.post(api.articles.create.path, isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user?.claims?.sub;
      const user = await authStorage.getUser(userId);
      if (!user) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      if (!user.isApproved && user.role !== "admin") {
        return res.status(403).json({ message: "Your account is pending approval by an admin." });
      }
      
      const input = api.articles.create.input.parse(req.body);
      const article = await storage.createArticle({ ...input, authorId: userId });
      
      // Fetch fully populated to return ArticleResponse
      const populated = await storage.getArticles(userId);
      const result = populated.find(a => a.id === article.id);
      
      res.status(201).json(result);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.post(api.articles.upvote.path, isAuthenticated, async (req: any, res) => {
    const userId = req.user?.claims?.sub;
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    const articleId = Number(req.params.id);
    const article = await storage.getArticle(articleId);
    if (!article) {
      return res.status(404).json({ message: "Article not found" });
    }
    const result = await storage.toggleUpvote(articleId, userId);
    res.status(200).json(result);
  });

  return httpServer;
}