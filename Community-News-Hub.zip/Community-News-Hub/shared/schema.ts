import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Export everything from Replit Auth
export * from "./models/auth";
import { users } from "./models/auth";

// === TABLE DEFINITIONS ===
export const articles = pgTable("articles", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  url: text("url").notNull(),
  authorId: text("author_id").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const upvotes = pgTable("upvotes", {
  id: serial("id").primaryKey(),
  articleId: integer("article_id").notNull().references(() => articles.id),
  userId: text("user_id").notNull().references(() => users.id),
});

// === RELATIONS ===
export const articlesRelations = relations(articles, ({ one, many }) => ({
  author: one(users, {
    fields: [articles.authorId],
    references: [users.id],
  }),
  upvotes: many(upvotes),
}));

export const upvotesRelations = relations(upvotes, ({ one }) => ({
  article: one(articles, {
    fields: [upvotes.articleId],
    references: [articles.id],
  }),
  user: one(users, {
    fields: [upvotes.userId],
    references: [users.id],
  }),
}));

// === BASE SCHEMAS ===
export const insertArticleSchema = createInsertSchema(articles).omit({ id: true, createdAt: true, authorId: true });
export const insertUpvoteSchema = createInsertSchema(upvotes).omit({ id: true, userId: true });

// === EXPLICIT API CONTRACT TYPES ===
export type Article = typeof articles.$inferSelect;
export type InsertArticle = z.infer<typeof insertArticleSchema>;
export type Upvote = typeof upvotes.$inferSelect;
export type InsertUpvote = z.infer<typeof insertUpvoteSchema>;

export type CreateArticleRequest = InsertArticle;
export type UpvoteRequest = { articleId: number };

export type ArticleResponse = Article & {
  author: { id: string; firstName: string | null; lastName: string | null; email: string | null };
  upvoteCount: number;
  hasUpvoted: boolean;
};

export type ArticlesListResponse = ArticleResponse[];
