import { Layout } from "@/components/layout";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Clock } from "lucide-react";

export default function PendingApproval() {
  const { logout } = useAuth();

  return (
    <Layout>
      <div className="container max-w-md mx-auto px-4 py-20 text-center">
        <Card className="border-border/60 shadow-xl">
          <CardHeader>
            <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <Clock className="h-8 w-8 text-primary" />
            </div>
            <CardTitle className="text-2xl font-display">Approval Pending</CardTitle>
            <CardDescription>
              Your account has been created successfully, but it requires admin approval before you can access the community.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Please check back later. Once an admin approves your request, you'll be able to view and post news.
            </p>
            <Button variant="outline" className="w-full" onClick={() => logout()}>
              Log Out
            </Button>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}