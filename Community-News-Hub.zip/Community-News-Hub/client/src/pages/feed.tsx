import { useArticles } from "@/hooks/use-articles";
import { ArticleCard } from "@/components/article-card";
import { Layout } from "@/components/layout";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertCircle, TrendingUp } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function Feed() {
  const { data: articles, isLoading, error } = useArticles();

  return (
    <Layout>
      <div className="container max-w-4xl mx-auto px-4 py-8">
        <div className="flex items-center gap-3 mb-8">
          <div className="p-2 bg-accent/10 rounded-lg">
            <TrendingUp className="h-6 w-6 text-accent" />
          </div>
          <h1 className="text-3xl font-display font-bold">Top Stories</h1>
        </div>

        <div className="space-y-4">
          {isLoading ? (
            // Loading Skeletons
            Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="flex gap-4 p-6 bg-card rounded-xl border border-border/50">
                <div className="flex flex-col items-center gap-2 pt-1">
                  <Skeleton className="h-8 w-8 rounded-lg" />
                  <Skeleton className="h-4 w-6" />
                </div>
                <div className="flex-1 space-y-3">
                  <Skeleton className="h-6 w-3/4" />
                  <Skeleton className="h-4 w-1/2" />
                </div>
              </div>
            ))
          ) : error ? (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>
                Failed to load articles. Please try again later.
              </AlertDescription>
            </Alert>
          ) : articles?.length === 0 ? (
            <div className="text-center py-20 bg-muted/10 rounded-2xl border border-dashed border-border">
              <h3 className="text-xl font-medium mb-2">No articles yet</h3>
              <p className="text-muted-foreground">Be the first to submit a story!</p>
            </div>
          ) : (
            articles?.map((article, index) => (
              <ArticleCard key={article.id} article={article} index={index} />
            ))
          )}
        </div>
      </div>
    </Layout>
  );
}
