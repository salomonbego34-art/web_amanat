import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useLocation } from "wouter";
import { useCreateArticle } from "@/hooks/use-articles";
import { insertArticleSchema } from "@shared/schema";
import { api, type ArticleInput } from "@shared/routes";
import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Send } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";

export default function Submit() {
  const [, setLocation] = useLocation();
  const { mutate: createArticle, isPending } = useCreateArticle();
  const { toast } = useToast();
  const { isAuthenticated, isLoading: authLoading } = useAuth();

  const form = useForm<ArticleInput>({
    resolver: zodResolver(api.articles.create.input),
    defaultValues: {
      title: "",
      url: "",
    },
  });

  // Protect route
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      setLocation("/");
    }
  }, [authLoading, isAuthenticated, setLocation]);

  function onSubmit(data: ArticleInput) {
    createArticle(data, {
      onSuccess: () => {
        toast({
          title: "Article Submitted!",
          description: "Your story has been posted successfully.",
        });
        setLocation("/");
      },
      onError: (error) => {
        toast({
          title: "Submission Failed",
          description: error.message,
          variant: "destructive",
        });
      },
    });
  }

  if (authLoading) return null; // Or a loading spinner

  return (
    <Layout>
      <div className="container max-w-2xl mx-auto px-4 py-12">
        <Card className="border-border/60 shadow-xl bg-card/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-2xl font-display">Submit a Story</CardTitle>
            <CardDescription>
              Share something interesting with the community. URLs are required.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Title</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="What's this story about?" 
                          className="h-12 text-lg" 
                          {...field} 
                        />
                      </FormControl>
                      <FormDescription>
                        Make it catchy but descriptive.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="url"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>URL</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="https://example.com/article" 
                          className="font-mono text-sm"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="pt-4 flex justify-end gap-4">
                  <Button 
                    type="button" 
                    variant="ghost" 
                    onClick={() => setLocation("/")}
                    disabled={isPending}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit" 
                    className="min-w-[120px]"
                    disabled={isPending}
                  >
                    {isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Posting...
                      </>
                    ) : (
                      <>
                        <Send className="mr-2 h-4 w-4" />
                        Submit
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
