import { type ArticleResponse } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { ArrowBigUp, MessageSquare, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useUpvoteArticle } from "@/hooks/use-articles";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { redirectToLogin } from "@/lib/auth-utils";
import { cn } from "@/lib/utils";

interface ArticleCardProps {
  article: ArticleResponse;
  index: number;
}

export function ArticleCard({ article, index }: ArticleCardProps) {
  const { mutate: upvote, isPending } = useUpvoteArticle();
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();

  const handleUpvote = () => {
    if (!isAuthenticated) {
      redirectToLogin(toast as any);
      return;
    }
    upvote(article.id);
  };

  const domain = new URL(article.url).hostname.replace('www.', '');

  return (
    <div 
      className="group relative flex gap-4 p-6 bg-card hover:bg-accent/5 rounded-xl border border-border/50 transition-all duration-300 hover:border-border hover:shadow-md"
      style={{ animationDelay: `${index * 50}ms` }}
    >
      {/* Upvote Section */}
      <div className="flex flex-col items-center gap-1 pt-1">
        <Button
          variant="ghost"
          size="sm"
          className={cn(
            "h-10 w-10 p-0 rounded-lg transition-colors hover:bg-primary/10 hover:text-primary",
            article.hasUpvoted && "text-primary bg-primary/10"
          )}
          onClick={handleUpvote}
          disabled={isPending}
        >
          <ArrowBigUp className={cn("h-8 w-8", article.hasUpvoted && "fill-current")} />
        </Button>
        <span className="text-sm font-bold text-muted-foreground tabular-nums">
          {article.upvoteCount}
        </span>
      </div>

      {/* Content Section */}
      <div className="flex-1 min-w-0">
        <div className="flex flex-col gap-1">
          <h3 className="font-display font-semibold text-lg md:text-xl leading-tight">
            <a 
              href={article.url} 
              target="_blank" 
              rel="noopener noreferrer"
              className="hover:text-primary transition-colors flex items-center gap-2 group/link"
            >
              {article.title}
              <ExternalLink className="h-4 w-4 opacity-0 -translate-y-1 translate-x-1 transition-all group-hover/link:opacity-100 group-hover/link:translate-y-0 group-hover/link:translate-x-0 text-muted-foreground" />
            </a>
          </h3>
          
          <div className="flex items-center flex-wrap gap-x-2 gap-y-1 text-sm text-muted-foreground mt-1">
            <span className="text-primary/80 font-medium">{domain}</span>
            <span className="text-border">•</span>
            <span>posted by <span className="text-foreground font-medium">{article.author.firstName || "User"}</span></span>
            <span className="text-border">•</span>
            <span suppressHydrationWarning>{formatDistanceToNow(new Date(article.createdAt || Date.now()), { addSuffix: true })}</span>
          </div>
        </div>

        {/* Mobile Actions / Metadata */}
        <div className="mt-4 flex items-center gap-4">
          <Button variant="ghost" size="sm" className="h-8 px-2 text-muted-foreground hover:text-foreground">
            <MessageSquare className="h-4 w-4 mr-1.5" />
            Discuss
          </Button>
        </div>
      </div>
    </div>
  );
}
