import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Feed from "@/pages/feed";
import Submit from "@/pages/submit";
import Landing from "@/pages/landing";
import AdminDashboard from "@/pages/admin-dashboard";
import PendingApproval from "@/pages/pending-approval";
import { useAuth } from "@/hooks/use-auth";

function Router() {
  const { user, isAuthenticated, isLoading } = useAuth();

  if (isLoading) return null;

  if (isAuthenticated && !user?.isApproved && user?.role !== "admin") {
    return (
      <Switch>
        <Route component={PendingApproval} />
      </Switch>
    );
  }

  return (
    <Switch>
      <Route path="/" component={isAuthenticated ? Feed : Landing} />
      <Route path="/feed" component={Feed} />
      <Route path="/submit" component={Submit} />
      <Route path="/admin" component={user?.role === "admin" ? AdminDashboard : NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
