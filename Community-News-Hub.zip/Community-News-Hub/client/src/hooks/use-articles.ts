import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type ArticleInput } from "@shared/routes";
import { type ArticleResponse } from "@shared/schema";

export function useArticles() {
  return useQuery({
    queryKey: [api.articles.list.path],
    queryFn: async () => {
      const res = await fetch(api.articles.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch articles");
      return await res.json() as ArticleResponse[];
    },
  });
}

export function useCreateArticle() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: ArticleInput) => {
      // Validate with schema first
      const validated = api.articles.create.input.parse(data);
      
      const res = await fetch(api.articles.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 401) throw new Error("Unauthorized");
        if (res.status === 400) {
          const error = await res.json();
          throw new Error(error.message || "Validation failed");
        }
        throw new Error("Failed to create article");
      }
      return await res.json() as ArticleResponse;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.articles.list.path] });
    },
  });
}

export function useUpvoteArticle() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (articleId: number) => {
      const url = buildUrl(api.articles.upvote.path, { id: articleId });
      const res = await fetch(url, {
        method: "POST",
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 401) throw new Error("Unauthorized");
        throw new Error("Failed to upvote");
      }
      return await res.json() as { upvoted: boolean; upvoteCount: number };
    },
    onSuccess: () => {
      // Invalidate to refresh all counts, though optimistic updates in UI handle the immediate feedback
      queryClient.invalidateQueries({ queryKey: [api.articles.list.path] });
    },
  });
}
